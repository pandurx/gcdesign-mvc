using FluentValidation;
using FluentValidation.Results;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Sample.MVC.Models;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics;


namespace Sample.MVC.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }


        public IActionResult Index()
        {
            Person person = new Person();

            return View(person);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        [HttpPost]
        public async Task<IActionResult> Index( Person person)
        {
            // file upload
            //var filePath = Directory.GetCurrentDirectory();
            //using (var stream = System.IO.File.Create(filePath + @"\Testing.txt"))
            //{
            //    await person.FileUpload.CopyToAsync(stream);

            //}

            // fluent validation
            PersonValidator validator = new();
            FluentValidation.Results.ValidationResult result = validator.Validate(person);

            if (result.IsValid) 
            {
                // proceed to submit
            } else
            {
                foreach (ValidationFailure failure in result.Errors) 
                {
                    ModelState.AddModelError(failure.PropertyName, failure.ErrorMessage);
                }
                
            }

            return View(person);
        }
    }

    public class PersonValidator : AbstractValidator<Person>
    {
        public PersonValidator() 
        {
            RuleFor(x => x.Gender).NotNull().WithMessage("Required user input");
            RuleFor(x => x.PersonName).SetValidator(new PersonNameValidator());
        }
    }

    public class PersonNameValidator : AbstractValidator<PersonName>
    {
        public PersonNameValidator()
        {
            RuleFor(x => x.Firstname).MaximumLength(5).WithMessage("Cannot exceed 5 characters");
        }
    }
}
