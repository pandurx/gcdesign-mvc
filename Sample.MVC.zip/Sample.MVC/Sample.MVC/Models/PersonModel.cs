﻿using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;

namespace Sample.MVC.Models
{
    public class Person
    {
        public PersonName PersonName { get; set; } = new();
        public string Gender { get;set; }

        public string CheckOptions { get;set; }

        public string Selection { get;set; }

        public IFormFile FileUpload { get;set; }

    }

    public class PersonName
    {
        public string Firstname { get; set; } = string.Empty;
        public string Lastname { get; set; } = string.Empty;
        public string PhoneNumber { get; set; } = string.Empty;
    }
}
